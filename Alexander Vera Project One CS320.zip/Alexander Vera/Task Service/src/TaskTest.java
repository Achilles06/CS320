import org.junit.Test;

public class TaskTest{
	
	@Test
	public void creatingTaskTest() {
		Task test1 = new Task("ID564987", "Niel Cuckman", "TLOU2 had horrible writing.");			
	}		
}