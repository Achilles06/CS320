import java.util.ArrayList;

public class TaskService {
	
	ArrayList<Task>tasks;
	
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	//add contact
	public void addTask(Task newTask) {
		for(Task c: tasks) {
			if(c.getTaskID().equalsIgnoreCase(newTask.getTaskID())) {
				System.out.println("Task ID already exists.");
				break;
			}
			else{tasks.add(newTask);
			System.out.println("Task added");
			}
		}	
	}
	
	//delete contact
	public void deleteTask(String contactID) {
		for(Task c:tasks) {
			if(c.getTaskID().equalsIgnoreCase(contactID)) {
				tasks.remove(c);
				System.out.println("Task- deleted.");
				break;
			}
		}
	}
	
	//update first name
	public void updateName(String taskID, String updatedN) {
		for(Task c:tasks) {
			if(c.getTaskID().equalsIgnoreCase(taskID)) {
				c.setName(updatedN);
				System.out.println("Name updated.");
				break;
			}
		}
	}
	
	//update last name
	public void updateDescription(String taskID, String updatedDes) {
		for(Task c:tasks) {
			if(c.getTaskID().equalsIgnoreCase(taskID)) {
				c.setDescription(updatedDes);
				System.out.println("Description updated.");
				break;
			}
		}
	}
}