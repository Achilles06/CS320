import org.junit.jupiter.api.Test;

public class TaskServiceTest{
	
	@Test
	public void testingTaskService() {
		
		TaskService service = new TaskService();
		service.addTask(new Task("ID456123", "TWD","Rick Grimes is a beast."));
		service.addTask(new Task("ID976134", "Mayans MC", "Eazy does it."));
		service.addTask(new Task("ID123344", "Peaky Blinders", "Tommy Shelby is a g."));
		
		service.deleteTask("ID456123");
		service.updateName("ID976134", "Ghost");
		service.updateDescription("ID976134", "Ghost is alive. Hopefully.");
		
		
	}
}