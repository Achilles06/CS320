import static org.junit.jupiter.api.Assertions.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
	@Test
	public void addNewAppointment() {
		ArrayList<Appointment>info;
		info = new ArrayList<>();
		AppointmentService appointments = new AppointmentService();
		Appointment test1 = new Appointment("Dave", new Date(2022,Calendar.AUGUST,12), "This is a test.");
		appointments.addAppointment(test1);
		appointments.deleteAppointment("Dave");
		info.add(test1);
		
	}

}