import java.util.Date;

public class Appointment {

	private String aID;
	private Date aDate;
	private String aDescription;
	
	public Appointment() {};
	
	public Appointment(String apID, Date apDate, String apDescription) {
		if(apID.length() <= 10 && apID != null) {
			this.aID = apID;
		}
		this.setaDate(apDate);
		this.setaDescription(apDescription);		
	}
	
	
	public void setaDate(Date apDate) {
		if(apDate == null || apDate.before(new Date())) {
			System.out.println("Please enter valide Date");
		}
	}
	
	public Date getaDate() {
		return aDate;
	}
	
	public void setaDescription(String apDescription) {
		if(apDescription == null) {
			System.out.println("Please enter a value");
		}
		
		if(apDescription.length() > 50) {
			System.out.println("Too many characters, please shorten description.");
		}
		
		if(apDescription != null && apDescription.length() <= 50) {
			this.aDescription = apDescription;
			
		}
	}
	
	public String getaDescription() {
		return aDescription;
	}
	
	public String getaID() {
		return aID;
	}
}
