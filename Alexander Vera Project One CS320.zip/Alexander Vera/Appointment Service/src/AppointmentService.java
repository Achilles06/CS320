import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {

	static ArrayList<Appointment>info;
	
	public AppointmentService() {
		info = new ArrayList<>();
	}
	
	public static void addAppointment(Appointment newAppointment) {		 
		for(Appointment a: info) 
			if(a.getaID().equalsIgnoreCase(newAppointment.getaID())) {
				System.out.println("Appointment already exists.");
				break;
			}
			else{info.add(newAppointment);
			System.out.println("Appointment added");
			}
		}	
	

	
	public void deleteAppointment(String aID) {
		for(Appointment a:info) {
			if(a.getaID().equalsIgnoreCase(aID)) {
				info.remove(a);
				System.out.println("Appointment deleted.");
				break;
			}
		}
	}
	
	public void displayAll() {
		for(Appointment a:info) {
			System.out.println(a.toString());
		}
	}
}
