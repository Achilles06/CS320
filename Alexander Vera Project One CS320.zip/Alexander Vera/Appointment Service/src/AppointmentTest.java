import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	
	@Test
	public void createNewAppointmentTest() {
		Appointment Apptest1 = new Appointment("Dave", new Date(2022,Calendar.AUGUST,12), "This is a test.");

	}
	
	

}