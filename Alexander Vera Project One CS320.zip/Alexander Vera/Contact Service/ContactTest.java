import org.junit.jupiter.api.Test;


public class ContactTest{
	
	@Test 
	public void creatingContact() {
	Contact test1 = new Contact("ID888888", "Miguel", "Galindo", "8086164789", "888 Biker City");
}
}