
import org.junit.jupiter.api.Test;

public class ContactServiceTest{
	
	@Test
	public void testAddContact() {
		ContactService CST = new ContactService();
		Contact test1 = new Contact("ID019287", "James", "Brown", "8084042665","123 Hollow Drive");		
		/*Assertions.assertEquals(true, CST.addContact(test1));*/
	}
	
	@Test
	public void testDelete() {
		ContactService CST = new ContactService();
		
		Contact test11 = new Contact("ID11111", "James", "Brown", "1011111111","111 Hollow Drive");
		Contact test2 = new Contact("ID222222", "Emily", "Irish", "2022222222","222 Headless Horseman");
		Contact test3 = new Contact("ID333333", "Chole", "GB", "3033333333","333 John Depp");
		
		CST.addContact(test11);
		CST.addContact(test2);
		CST.addContact(test3);
		
		CST.deleteContact("ID111111");
		CST.deleteContact("ID222222");
		CST.deleteContact("ID333333");
			
	}
		
	@Test
	public void testUpdateFirstName() {
		ContactService CST = new ContactService();
		Contact test11 = new Contact("ID11111", "James", "Brown", "1011111111","111 Hollow Drive");
		CST.updatefirstName("ID11111", "High");
	}
	
	@Test
	public void testUpdateLastName() {
		ContactService CST = new ContactService();
		Contact test11 = new Contact("ID11111", "James", "Brown", "1011111111","111 Hollow Drive");
		CST.updatelastName("ID11111", "Tree");
	}
	
	@Test
	public void testupdatePhoneNumber() {
		ContactService CST = new ContactService();
		Contact test11 = new Contact("ID11111", "James", "Brown", "1011111111","111 Hollow Drive");
		CST.updateNumber("ID11111", "8087071111");
	}
	
	@Test
	public void testUpdateaddress() {
		ContactService CST = new ContactService();
		Contact test11 = new Contact("ID11111", "James", "Brown", "1011111111","111 Hollow Drive");
		CST.updateAddress("ID11111", "606 Dont Drive that Way");
	}
}
