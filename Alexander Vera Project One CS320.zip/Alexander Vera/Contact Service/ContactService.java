import java.util.ArrayList;

public class ContactService{
	
	ArrayList<Contact>contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	//add contact
	public void addContact(Contact newContact) {
		for(Contact c: contacts) {
			if(c.getContactID().equalsIgnoreCase(newContact.getContactID())) {
				System.out.println("Contact name already exists.");
				break;
			}
			else{contacts.add(newContact);
			System.out.println("Contact added");
			}
		}	
	}
	
	//delete contact
	public void deleteContact(String contactID) {
		for(Contact c:contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				contacts.remove(c);
				System.out.println("Contact deleted.");
				break;
			}
		}
	}
	
	//update first name
	public void updatefirstName(String contactID, String updatedFN) {
		for(Contact c:contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setfirstName(updatedFN);
				System.out.println("First name updated.");
				break;
			}
		}
	}
	
	//update last name
	public void updatelastName(String contactID, String updatedLN) {
		for(Contact c:contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setlastName(updatedLN);
				System.out.println("Last name updated.");
				break;
			}
		}
	}
	
	//update phone number
	public void updateNumber(String contactID, String updatedPN) {
		for(Contact c:contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setphoneNumber(updatedPN);
				System.out.println("Phone number updated.");
				break;
			}
		}
	}
	
	//update address
	public void updateAddress(String contactID, String updatedaddress) {
		for(Contact c:contacts) {
			if(c.getContactID().equalsIgnoreCase(contactID)) {
				c.setAddress(updatedaddress);
				System.out.println("Address updated.");
				break;
			}
		}
	}
	
	//print contact list
	public void showContacts() {
		for(Contact c:contacts) {
			System.out.println(c);
		}
	}
}