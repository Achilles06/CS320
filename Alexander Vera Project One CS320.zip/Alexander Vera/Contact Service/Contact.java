

public class Contact {

	//objects properties 
	private String contactID; 
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public Contact() {}
	
	public Contact(String contactid, String firstname, String lastname, String phonenumber, String address) {
		if(contactid.length() <= 10 && contactid != null) {
			this.contactID = contactid;
		}
		this.setfirstName(firstname);
		this.setlastName(lastname);
		this.setphoneNumber(phonenumber);
		this.setAddress(address);
		
	}
	
	public String getContactID() {
		return contactID;
	}

	public void setfirstName(String firstname) {
		if(firstname.length() <= 10 && firstname != null) {
			this.firstName = firstname;
		}
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setlastName(String lastname) {
		if(lastname.length() <= 10 && lastname != null) {
			this.lastName = lastname;
		}
	}
	
	public String getLastName() {
		return lastName;
	}

	public void setphoneNumber(String phonenumber) {
		if(phonenumber.length() <= 10 && phonenumber != null) {
			this.phoneNumber = phonenumber;
		}
	}
	
	public String phoneNumber() {
		return phoneNumber;
	}
	
	public void setAddress(String address) {
		if(address.length()<= 30 && address != null) {
			this.address = address;
		}
	}
	
	public String getAddress() {
		return address;
	}
	
	@Override
	public String toString() {
		return "Contact: " + contactID + ", first name: " + firstName + ", last name: " + lastName + "phone number: "
	+ phoneNumber + ", address: " + address;}
}